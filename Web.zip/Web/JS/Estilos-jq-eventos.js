$(document).ready(function(){
	//Función que elige los eventos conforme el año seleccionado
	$(".js-anio").click(function(){
		$(".anio-focused").removeClass("anio-focused");
		$(this).addClass("anio-focused");
		if($(this).attr("id") == "2016") {
			$(".main-eventos-display").removeClass("anio-no-selected");
			$(".main-eventos-anio").addClass("anio-no-selected");
		}
		else {
			$(".titu-eventos-anio").html("Eventos pasados del " + $(this).attr("id"));
			$(".anio-no-selected").removeClass("anio-no-selected");
			$(".main-eventos-display").addClass("anio-no-selected");
		}
	});

	//Función para abrir el float de eventos
	$(".evento").click(function(){
		$(".evento-float").toggle("fast");
		$("body").css("overflowY", "hidden");
	});

	$(".evento-img").click(function(){
		$(".img-float").toggle("fast");
		$(".img-big").attr("src", $(this).children("img").attr("src"));
		$(".btn-evento-atras").toggle("fast");
	});

	$(".btn-big-atras").click(function(){
		$(".img-float").toggle("fast");
		$(".btn-evento-atras").toggle("fast");
	});

	$(".btn-evento-atras").click(function(){
		$(".evento-float").toggle("fast");
		$("body").css("overflowY", "scroll");
	});

});