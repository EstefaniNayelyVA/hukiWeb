//ESTILOS JQ
$(document).ready(function(){

	//Función del icono para abrir menú
	$(".btn-menu").click(function() {
		$(this).toggleClass("btn-menu-lines");
		$(this).toggleClass("btn-menu-cross");
		$("div.main-nav").slideToggle(400);
		//Agrega y quita una clase al menu-icon
		$(this).toggleClass("btn-menu-active");
	});

	//Overflow body
	$(".btn-menu-lines").click(function(){
		$("body").toggleClass("overflow-false");
	});

	$("btn-menu-cross").click(function(){
		$("body").toggleClass("overflow-true");
	})

	//BOTONES QUE DESPLIEGAN LOS FORMULARIOS DE JUGADOR, COACH, HUNTER
	$(".btn-jugador").click(function(){
		$(".jugador").addClass("show-form");
		$(".jugador").removeClass("hide-form");
		$(".login-cuenta").addClass("show-form");
		$(".login-cuenta").removeClass("hide-form");
		$(".entrenador").addClass("hide-form");
		$(".entrenador").removeClass("show-form");
	});

	$(".btn-entrenador").click(function(){
		$(".entrenador").addClass("show-form");
		$(".entrenador").removeClass("hide-form");
		$(".login-cuenta").addClass("show-form");
		$(".login-cuenta").removeClass("hide-form");
		$(".jugador").addClass("hide-form");
		$(".jugador").removeClass("show-form");
	});

	//CLICK EN LA TABLA
	//$("tr.jugadorRow").click(function() {
	  //  var tableData = $(this).children("td").map(function() {
	        return $(this).text();
	   // }).get();

	    //alert(tableData[2]);
	//});

	//FUNCIONES PARA EL LOGIN
	//Función para mostrar el pestañas de opciones login y registro
	$(".btn-login").click(function(){
  		$(".login").toggle("fast");
  		$(".js-hide").toggleClass("a-active");
	});

	//Función para cerrar login
	$(".btn-cerrar").click(function(){
		$(".login").toggle("fast");
	});

	//Función para ir atrás
	$(".btn-atras-1").click(function(){
  		$(".sub-login-before-ing").toggle("fast");
  		$(".js-hide").toggleClass("a-active");
	});

	//Función para ir atrás
	$(".btn-atras-2").click(function(){
  		$(".sub-login-before-reg").toggle("fast");
  		$(".js-hide").toggleClass("a-active");
  		$(".login-data").toggleClass("login-data-active");
	});

	//Funcion para mostrar login
	$(".j").click(function(){
  		$(".sub-login-before-ing").toggle("fast");
	});

	//Función para mostrar registro
	$(".jj").click(function(){
  		$(".sub-login-before-reg").toggle("fast");
  		$(".login-data").toggleClass("login-data-active");
	});

	//Función para esconder clase a-active
	$(".js-hide").click(function(){
  		$(".js-hide").toggleClass("a-active");
	});

	//Función para mostrar label de los input cuando están
	//seleccionados o contienen un valor
	$("input").focus(function(){
		$(this).parent().addClass("focused");
	}).blur(function(){
		var check = $.trim($(this).val());

		if(check.length > 0)
			$(this).parent().addClass("populated");
		else{
			$(this).parent().removeClass("focused");
			$(this).parent().removeClass("populated");
		}
	});


	//MENU
	//Función para el formulario multinivel
    $("li.main-nav-ls-i").each(function() {
      var $dropdown = $(this);

        $(".i", $dropdown).click(function(e) {
            e.preventDefault();
            $div = $("div.sub-nav", $dropdown);
            $div.slideToggle("slow");
            $("div.sub-nav").not($div).slideUp("fast");
            return false;
        });

	});
});
