function abrirMenu(){
	document.getElementById("menuIzquierda").style.width = "100%";
	document.getElementById("menuIzquierda").style.height = "100%";
	document.getElementById("menuIzquierda").style.backgroundColor = "#111";
}

function cerrarMenu(){
	document.getElementById("menuIzquierda").style.height = "0%";
	document.getElementById("menuIzquierda").style.width = "0%";
	document.getElementById("menuIzquierda").style.backgroundColor = "#ffffff";
}