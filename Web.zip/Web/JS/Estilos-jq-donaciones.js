//Funciones JQuery

$(document).ready(function(){
	//Funcion que da click al icono del menú para
	//cerrar el main-nav cuando se da click a 
	//un cuadro de donaciones
	$(".js-entrada").click(function(){
		if($("li.main-nav-ls-i").is(":visible"))
			$(".btn-menu").trigger("click");
	})
});