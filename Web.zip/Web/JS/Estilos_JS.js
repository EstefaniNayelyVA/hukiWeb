
//Archivo JS


//SLIDERS
var sliderCount = 1;

function imgSliderNext(){
	if(sliderCount==3){
		document.getElementById("imgSlider").src = "../Imagenes/Paisajes-Relajantes-Playas.jpg"
		sliderCount=1;
	}
	else if(sliderCount==1){
		document.getElementById("imgSlider").src = "../Imagenes/playa-2-palmera.jpg";
		sliderCount++;
	}
	else if(sliderCount==2){
		document.getElementById("imgSlider").src = "../Imagenes/playas.jpg"
		sliderCount++;
	}
}

function imgSliderPrev(){
	if(sliderCount==2){
		document.getElementById("imgSlider").src = "../Imagenes/Paisajes-Relajantes-Playas.jpg"
		sliderCount--;
	}
	else if(sliderCount==3){
		document.getElementById("imgSlider").src = "../Imagenes/playa-2-palmera.jpg";
		sliderCount--;
	}
	else if(sliderCount==1){
		document.getElementById("imgSlider").src = "../Imagenes/playas.jpg"
		sliderCount=3;
	}
}

function carousel() {
    var i;
    var x = document.getElementsByClassName("imgS");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    sliderCount++;
    if (sliderCount > x.length) {sliderCount = 1}
    x[sliderCount-1].style.display = "block";
    setTimeout(carousel, 10000);
}

//CLICKS

//Funciones que abren div menu y div sub-menu
function openMenu(){
	var width = document.body.clientWidth;

	if (width < 750) {
		document.getElementById("menu").style.height = "300px";
		document.getElementById("menu").style.margin = "3% 0 0 0";
	}
	else
		document.getElementById("menu").style.height = "300px";
	
}

function closeMenu(){
	document.getElementById("menu").style.height = "0";
	document.getElementById("menu").style.margin= "0";
}

function abrirSMenu(n){
	var x = document.getElementById("sub-menu-" + n);
	var y = document.getElementsByClassName("menu-sub-" + n);
	switch(n)
	{
		case 1:
		x.style.height = "120px";
		x.style.borderBottom = "3px solid #111";
		y[0].style.backgroundColor = "#FFF";
		y[0].style.color = "#999";
		break;
	}
}
//Funciones que abren div login
var openClose = 1;
function openCloseLogin(){
	var width = document.body.clientWidth;
	if(openClose == 1){
		if (width < 750) {
			document.getElementById("login").style.height = "300px";
			document.getElementById("login").style.margin = "3% 0";
		}
		else
			document.getElementById("login").style.height = "300px";
			
		openClose++;
	}
	else if(openClose == 2){
		document.getElementById("login").style.height = "0";
		document.getElementById("login").style.margin = "0 0";		
		openClose=1;
	}
	
}

//Funciones para el div noticias-m
var openCloseN = 1;
function notContenido(btnI) {
	switch(btnI) {
		case 1:
			document.getElementById("not-titulo").innerHTML = "Apoyanos Donando";
			document.getElementById("not-descripcion").innerHTML = "Puedes donar demasiadas cosas para apoyarnos, la fundación y ellos necesitan de ti. Por favor no les quites tu apoyo.";
			document.getElementById("btnVer").href = "Donaciones.html";
			break;
		case 2:
			document.getElementById("not-titulo").innerHTML = "Sobre Nosotros";
			document.getElementById("not-descripcion").innerHTML = "Somos una fundación que se mantiene del apoyo de la gente y da hogar a animales en condiciones de calle. Aprende sobre nosotros.";
			document.getElementById("btnVer").href = "Fundacion.html";
			break;
		case 3:
			document.getElementById("not-titulo").innerHTML = "Eventos";
			document.getElementById("not-descripcion").innerHTML = "Conoce sobre los eventos m-as recientes que hemos organizado y verifica los próximos eventos por venir. Próximo evento 07-Diciembre.";
			document.getElementById("btnVer").href = "Eventos.html";
			break;
		case 4:
			document.getElementById("not-titulo").innerHTML = "Adoptadores Más Recientes";
			document.getElementById("not-descripcion").innerHTML = "Te presentamos a los adoptadores que le han dado (recientemente) hogar a unos de nuestros Fabulososo amigos peludos.";
			document.getElementById("btnVer").href = "Adoptadores.html";
			break;	
		case 5:
			document.getElementById("not-titulo").innerHTML = "Adopta";
			document.getElementById("not-descripcion").innerHTML = "Dale hogar a alguno de nuetros peludos amigos, no los dejes esperando. Animatee y te aseguramos que no te arrepentirás.";
			document.getElementById("btnVer").href = "Adopciones.html";
			break;
		case 6:
			document.getElementById("not-titulo").innerHTML = "Preguntas Frecuentes";
			document.getElementById("not-descripcion").innerHTML = "Tienes alguna duda, como: ¿Dónde nos encontramos? ¿Horarios? Ingresa para resolver tus dudas.";
			document.getElementById("btnVer").href = "Preguntas.html";
			break;
	}
	
}

//FUNCIONES PARA DONACIONES
function mostrarInfo(tipo) {
	var x = document.getElementsByClassName("entr-info");
	var y = document.getElementsByClassName("opa-info");
	switch(tipo) {
		case 1:
			x[0].style.display = "block";
			y[0].style.height = "100%";
			document.body.style.overflowY = "hidden";
			break;
		case 2:
			x[1].style.display = "block";
			y[0].style.height = "100%";
			document.body.style.overflowY = "hidden";
			break;
		case 3:
			x[2].style.display = "block";
			y[0].style.height = "100%";
			document.body.style.overflowY = "hidden";
			break;
		case 4:
			x[3].style.display = "block";
			y[0].style.height = "100%";
			document.body.style.overflowY = "hidden";
			break;
	}
}

function cerrarInfo(tipo) {
	var x = document.getElementsByClassName("entr-info");
	var y = document.getElementsByClassName("opa-info");
	switch(tipo) {
		case 1:
			x[0].style.display = "none";
			y[0].style.height = "0";
			document.body.style.overflowY = "scroll";
			break;
		case 2:
			x[1].style.display = "none";
			y[0].style.height = "0";
			document.body.style.overflowY = "scroll";
			break;
		case 3:
			x[2].style.display = "none";
			y[0].style.height = "0";
			document.body.style.overflowY = "scroll";
			break;
		case 4:
			x[3].style.display = "none";
			y[0].style.height = "0";
			document.body.style.overflowY = "scroll";
			break;
	}
}

//FUNCIONES PARA EVENTOS
function fechaHoy() {
	var hoy = new Date();
	document.getElementById("fecha-actual").innerHTML = hoy.toDateString();
}

//FUNCIONES PARA PREGUNTAS
function mostrarPreg(p) {
	var x = document.getElementsByClassName("preg-desc");
	var opa = document.getElementsByClassName("opa-info");
	var titu = document.getElementById("desc-preg-titu");
	var tabl = document.getElementById("desc-preg-tbl");
	var desc = document.getElementById("desc-preg-desc");
	var link = document.getElementById("desc-preg-link"); 
	switch(p)
	{
		case 1:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Dónde están localizados?";
		tabl.style.display = "none";
		desc.innerHTML = "En algún lugar de la colonia el barrio frente al mercado.";
		link.style.display = "initial";
		link.href = "https://www.google.com.mx/maps/place/Fundaci%C3%B3n+Animare+Le%C3%B3n/@21.1307353,-101.68401,18z/data=!4m5!3m4!1s0x842bbf12dc14b079:0x8f0b0c13f1e2904b!8m2!3d21.1310056!4d-101.6829809?hl=es-419";
		document.body.style.overflowY = "hidden";
		break;
		case 2:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Cuáles son sus horarios?";
		tabl.style.display = "none";
		desc.innerHTML = "Nos encuentras de 9am-8pm de lunes a viernes. Sábados de 11am-3pm. Los domingos descansamos.";
		link.style.display = "none";
		document.body.style.overflowY = "hidden";
		break;
		case 3:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Tengo que pagar para adoptar?";
		tabl.style.display = "none";
		desc.innerHTML = "Los únicos gastos que se cubren al momento de la adopción son los de recuperación con un valor total de $300.00 M.N. No se cobra por el perro si no por las vacunas que este lleva y etc.";
		link.style.display = "none";
		document.body.style.overflowY = "hidden";
		break;
		case 4:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Precios de vacunas?";
		document.getElementById("tbl-preg").caption.innerHTML = "PRECIOS DE VACUNAS";
		tabl.style.display = "block";
		desc.innerHTML = "Traenos la cartilla de tu mascota y en caso de que no sepas cuál le toca, nosotros te decimos.";
		link.style.display = "none";
		document.body.style.overflowY = "hidden";
		break;
		case 5:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Abren en domingos?";
		tabl.style.display = "none";
		desc.innerHTML = "No. El domingo es el único día de la semana que no trabajamos."
		link.style.display = "none";
		document.body.style.overflowY = "hidden";
		break;
		case 6:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Por dónde se les puede contactar?";
		document.getElementById("tbl-preg").caption.innerHTML = "LISTA DE CONTACTOS";
		tabl.style.display = "block";
		desc.innerHTML = "Mostrar tabla con contactos.";
		link.style.display = "none";
		document.body.style.overflowY = "hidden";
		break;
		case 7:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Qué puedo donar?";
		tabl.style.display = "none";
		desc.innerHTML = "Puede donar dinero, productos de limpieza, medicamentos entre otros. Para sabe más sobre las donaciones que puede efectuar, le invitamos a pasar a nuestro apartado de donaciones.";
		link.innerHTML = "&#xf0fa;";
		link.target = "_self";
		link.style.display = "initial";
		link.href = "Donaciones.html";
		document.body.style.overflowY = "hidden";
		break;
		case 8:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Requisitos para ser voluntario?";
		tabl.style.display = "block";
		document.getElementById("tbl-preg").caption.innerHTML = "REQUISITOS VOLUNTARIADO";
		desc.innerHTML = "En caso de que deseara saber más, le invitamos a pasar a nuestro apartado voluntariado. En seguida se despliegan los requisitos para el voluntariado:";
		link.style.display = "initial";
		link.innerHTML = "&#xf256;";
		link.target = "_self";
		link.href = "Voluntarios.html";
		document.body.style.overflowY = "hidden";
		break;
		case 9:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Requisitos para ser adoptante?";
		tabl.style.display = "block";
		document.getElementById("tbl-preg").caption.innerHTML = "REQUISITOS ADOPCIÓN";
		desc.innerHTML = "Recomendamos que visite el apartado Adopciones-Requisitos para conocer a fondo todos los detalles. En seguida se despliegan los requisitos para la adopción:";
		link.style.display = "initial";
		link.innerHTML = "&#xf1b0;";
		link.target = "_self";
		link.href = "https://www.google.com.mx/maps/place/Fundaci%C3%B3n+Animare+Le%C3%B3n/@21.1307353,-101.68401,18z/data=!4m5!3m4!1s0x842bbf12dc14b079:0x8f0b0c13f1e2904b!8m2!3d21.1310056!4d-101.6829809?hl=es-419";
		document.body.style.overflowY = "hidden";
		break;
		case 10:
		x[0].style.width = "100%";
		opa[0].style.width = "100%";
		titu.innerHTML = "¿Por qué el cielo es azúl?";
		desc.innerHTML = "ANUMA SICIERTO";
		tabl.style.display = "none";
		link.style.display = "none";
		document.body.style.overflowY = "hidden";
		break;
	}
}

function cerrarPreg(p) {
	var x = document.getElementsByClassName("preg-desc");
	var opa = document.getElementsByClassName("opa-info");
	switch(p)
	{
		case 1:
		x[0].style.width = "0";
		opa[0].style.width = "0";
		document.body.style.overflowY = "scroll";
		break;
	}
}

//FUNCIONES PRUEBA