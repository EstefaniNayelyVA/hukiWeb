﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using HukiFinal2._0.Models;

namespace HukiFinal2._0.Controllers
{
    public class EntrenadorsController : ApiController
    {
        private HukiEntities db = new HukiEntities();

        // GET: api/Entrenadors
        public IQueryable<Entrenador> GetEntrenadors()
        {
            return db.Entrenadors;
        }

        // GET: api/Entrenadors/5
        [ResponseType(typeof(Entrenador))]
        public IHttpActionResult GetEntrenador(int id)
        {
            Entrenador entrenador = db.Entrenadors.Find(id);
            if (entrenador == null)
            {
                return NotFound();
            }

            return Ok(entrenador);
        }

        // PUT: api/Entrenadors/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutEntrenador(int id, Entrenador entrenador)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != entrenador.idEntrenador)
            {
                return BadRequest();
            }

            db.Entry(entrenador).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EntrenadorExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Entrenadors
        [ResponseType(typeof(Entrenador))]
        public IHttpActionResult PostEntrenador(Entrenador entrenador)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Entrenadors.Add(entrenador);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = entrenador.idEntrenador }, entrenador);
        }

        // DELETE: api/Entrenadors/5
        [ResponseType(typeof(Entrenador))]
        public IHttpActionResult DeleteEntrenador(int id)
        {
            Entrenador entrenador = db.Entrenadors.Find(id);
            if (entrenador == null)
            {
                return NotFound();
            }

            db.Entrenadors.Remove(entrenador);
            db.SaveChanges();

            return Ok(entrenador);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool EntrenadorExists(int id)
        {
            return db.Entrenadors.Count(e => e.idEntrenador == id) > 0;
        }
    }
}