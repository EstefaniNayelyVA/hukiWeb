﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using HukiFinal2._0.Models;

namespace HukiFinal2._0.Controllers
{
    public class Partidos_JugadosController : ApiController
    {
        private HukiEntities db = new HukiEntities();

        // GET: api/Partidos_Jugados
        public IQueryable<Partidos_Jugados> GetPartidos_Jugados()
        {
            return db.Partidos_Jugados;
        }

        // GET: api/Partidos_Jugados/5
        [ResponseType(typeof(Partidos_Jugados))]
        public IHttpActionResult GetPartidos_Jugados(int id)
        {
            Partidos_Jugados partidos_Jugados = db.Partidos_Jugados.Find(id);
            if (partidos_Jugados == null)
            {
                return NotFound();
            }

            return Ok(partidos_Jugados);
        }

        // PUT: api/Partidos_Jugados/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutPartidos_Jugados(int id, Partidos_Jugados partidos_Jugados)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != partidos_Jugados.idPartidosJugados)
            {
                return BadRequest();
            }

            db.Entry(partidos_Jugados).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Partidos_JugadosExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Partidos_Jugados
        [ResponseType(typeof(Partidos_Jugados))]
        public IHttpActionResult PostPartidos_Jugados(Partidos_Jugados partidos_Jugados)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Partidos_Jugados.Add(partidos_Jugados);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = partidos_Jugados.idPartidosJugados }, partidos_Jugados);
        }

        // DELETE: api/Partidos_Jugados/5
        [ResponseType(typeof(Partidos_Jugados))]
        public IHttpActionResult DeletePartidos_Jugados(int id)
        {
            Partidos_Jugados partidos_Jugados = db.Partidos_Jugados.Find(id);
            if (partidos_Jugados == null)
            {
                return NotFound();
            }

            db.Partidos_Jugados.Remove(partidos_Jugados);
            db.SaveChanges();

            return Ok(partidos_Jugados);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Partidos_JugadosExists(int id)
        {
            return db.Partidos_Jugados.Count(e => e.idPartidosJugados == id) > 0;
        }
    }
}