﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using HukiFinal2._0.Models;

namespace HukiFinal2._0.Controllers
{
    public class VisorsController : ApiController
    {
        private HukiEntities db = new HukiEntities();

        // GET: api/Visors
        public IQueryable<Visor> GetVisors()
        {
            return db.Visors;
        }

        // GET: api/Visors/5
        [ResponseType(typeof(Visor))]
        public IHttpActionResult GetVisor(int id)
        {
            Visor visor = db.Visors.Find(id);
            if (visor == null)
            {
                return NotFound();
            }

            return Ok(visor);
        }

        // PUT: api/Visors/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutVisor(int id, Visor visor)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != visor.idVisor)
            {
                return BadRequest();
            }

            db.Entry(visor).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VisorExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Visors
        [ResponseType(typeof(Visor))]
        public IHttpActionResult PostVisor(Visor visor)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Visors.Add(visor);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (VisorExists(visor.idVisor))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = visor.idVisor }, visor);
        }

        // DELETE: api/Visors/5
        [ResponseType(typeof(Visor))]
        public IHttpActionResult DeleteVisor(int id)
        {
            Visor visor = db.Visors.Find(id);
            if (visor == null)
            {
                return NotFound();
            }

            db.Visors.Remove(visor);
            db.SaveChanges();

            return Ok(visor);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool VisorExists(int id)
        {
            return db.Visors.Count(e => e.idVisor == id) > 0;
        }
    }
}