﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Huki_Cliente.Models;

namespace Huki_Cliente.ViewModels
{
    public class PersonaViewModel
    {
        public Persona Persona
        {
            get;
            set;
        }
    }
}