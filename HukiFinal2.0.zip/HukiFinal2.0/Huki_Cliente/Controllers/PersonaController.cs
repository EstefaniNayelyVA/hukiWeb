﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Huki_Cliente.Models;
using Huki_Cliente.ViewModels;

namespace Huki_Cliente.Controllers
{
    public class PersonaController : Controller
    {
        // GET: Persona
        public ActionResult Index()
        {
            PersonaCliente pc = new PersonaCliente();
            ViewBag.listPersonas = pc.encontrarTodo();
            return View();
        }

        [HttpGet]
        public ActionResult Registro()
        {
            return View("Registro");
        }

        [HttpPost]
        public ActionResult Registro(PersonaViewModel pvm)
        {
            PersonaCliente pc = new PersonaCliente();
            pc.Crear(pvm.Persona);
            return RedirectToAction("Index");
        }
    }
}