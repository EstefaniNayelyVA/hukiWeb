﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;

namespace Huki_Cliente.Models
{
    public class PersonaCliente
    {
        private String url = "http://localhost:11541/api/";

        public IEnumerable<Persona> encontrarTodo()
        {
            try
            {
                HttpClient cliente = new HttpClient();
                cliente.BaseAddress = new Uri(url);
                cliente.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage respuesta = cliente.GetAsync("personas").Result;
                if (respuesta.IsSuccessStatusCode)
                    return respuesta.Content.ReadAsAsync<IEnumerable<Persona>>().Result;
                return null;
            }
            catch (Exception)
            {
                return null;
                throw;
            }
        }

        public bool Crear(Persona personas)
        {
            try
            {
                HttpClient cliente = new HttpClient();
                cliente.BaseAddress = new Uri(url);
                cliente.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage respuesta = cliente.PostAsJsonAsync("personas", personas).Result;
                return respuesta.IsSuccessStatusCode;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}