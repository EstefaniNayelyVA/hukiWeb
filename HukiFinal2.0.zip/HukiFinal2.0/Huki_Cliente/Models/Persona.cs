﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Huki_Cliente.Models
{
    public class Persona
    {
        [Display(Name ="idPersona")]
        public int idPersona { get; set; }
        [Display(Name = "nombre")]
        public string nombre { get; set; }
        [Display(Name = "apellidoPaterno")]
        public string apellidoPaterno { get; set; }
        [Display(Name = "apellidoMaterno")]
        public string apellidoMaterno { get; set; }
        [Display(Name = "fechaNacimiento")]
        public System.DateTime fechaNacimiento { get; set; }
        [Display(Name = "telefono")]
        public string telefono { get; set; }
        [Display(Name = "genero")]
        public bool genero { get; set; }
        [Display(Name = "correo")]
        public string correo { get; set; }
        [Display(Name = "clave")]
        public string clave { get; set; }
        
    }
}